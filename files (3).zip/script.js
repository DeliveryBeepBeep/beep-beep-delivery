document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;

    // Exemplu simplu (validare pe server în realitate)
    if (username && password) {
        localStorage.setItem("user", JSON.stringify({ username, role }));
        if (role === "restaurant") {
            window.location.href = "dashboard-restaurant.html";
        } else if (role === "livrator") {
            window.location.href = "dashboard-livrator.html";
        }
    } else {
        document.getElementById("error-message").classList.remove("hidden");
    }
});